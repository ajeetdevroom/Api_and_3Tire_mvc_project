export class Student {
    constructor(
    public stdId:string,  
    public stdname:string,
    public stdAddress:string,
    public stdClass:string,
    public stdMobile:string,
    public stdEmail:string  
    )
    {}
}
